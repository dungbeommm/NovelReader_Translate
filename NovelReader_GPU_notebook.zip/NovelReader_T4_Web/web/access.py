"""Optional per-Colab-session access secret, exchanged for an HttpOnly cookie."""
import hmac
import os
from fastapi.responses import RedirectResponse, Response

COOKIE = 'novel_session_access'


def has_access(headers, cookies):
    required = os.getenv('NOVEL_WEB_ACCESS_TOKEN', '')
    if not required:
        return True  # local-only deployments keep the existing behavior
    supplied = headers.get('x-novel-access') or cookies.get(COOKIE, '')
    return hmac.compare_digest(str(supplied), required)


def protect_request(request):
    required = os.getenv('NOVEL_WEB_ACCESS_TOKEN', '')
    if not required:
        return None
    token = request.query_params.get('access_token', '')
    if request.url.path == '/' and token and hmac.compare_digest(token, required):
        response = RedirectResponse('/', status_code=303)
        response.set_cookie(COOKIE, required, httponly=True, samesite='strict',
                            secure=request.url.scheme == 'https', path='/')
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Cache-Control'] = 'no-store'
        return response
    if has_access(request.headers, request.cookies):
        return None
    return Response(
        'Chưa được phép truy cập.\n\n'
        'Quay lại tab Colab, mở ô Web đang chạy và bấm “Mở NovelReader”.\n'
        'Không dùng riêng địa chỉ trycloudflare.com hoặc link của phiên cũ.\n'
        'Sau khi khởi động lại Web, hãy dùng link mới được in trong notebook.\n'
        'Nếu mở trong trình duyệt khác hoặc chế độ ẩn danh, cần mở lại link riêng ở đó.\n'
        'Không chia sẻ link riêng vì link cấp quyền truy cập ứng dụng.\n',
        status_code=403, media_type='text/plain; charset=utf-8',
        headers={'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer'})
